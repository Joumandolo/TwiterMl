<?php
######## buscarTwitsJson.php
### primer experimento con twiter by Jou.
########
#
include_once($_SERVER['DOCUMENT_ROOT']."/twiter/twitteroauth2/twitteroauth/twitteroauth.php");

$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

//Crear objeto que contiene las credenciales de autenticacion
$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Recibir datos por get desde la funcion externa que invoca en formato Json
$query = array(
	"q" => $_GET["buscaTerm"],
	"rpp" => $_GET["rpp"],
	"lang" => $_GET["buscaIdioma"],
	"place" => $_GET["buscaUbicacion"],
	"since" => $_GET["buscaFechaHasta"],
	"until" => $_GET["buscaFechaDesde"]
	);

//Buscar twitts
$respuesta = $tweet->get("search.json?", $query);
//$contenido = json_decode($respuesta);

//volcar el contenido en los heders
header('Content-type: application/json');
echo $respuesta;
?>
 
