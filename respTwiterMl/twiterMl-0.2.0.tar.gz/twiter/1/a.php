<?php
$array = array("color" => array("blue", "red", "green"),
		"size"  => array("small", "medium", "large")
);
var_dump(array_keys($array["color"],"red"));
?>
