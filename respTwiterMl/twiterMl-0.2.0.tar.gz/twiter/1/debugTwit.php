<?php
######## debugTwit.php
## Estes escript forma parte del sistema TwiterML
## 
##
##			By: Jou - joumandolo@gmail.com
########

include_once($_SERVER['DOCUMENT_ROOT']."/twiter/twitteroauth2/twitteroauth/twitteroauth.php");
include($_SERVER['DOCUMENT_ROOT']."/tagCloud/classes/wordcloud.class.php");

echo '<link rel="stylesheet" href="../../tagCloud/css/wordcloud.css" type="text/css">';
 
$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

//Crear objeto que contiene las credenciales de autenticacion
$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Recibir datos por get desde la funcion externa que invoca en formato Json
$query = array(
	"q" => "educacion",
	);

//Buscar twitts
$respuesta = $tweet->get("search.json?", $query);
$contenido = json_decode($respuesta, true);

// Agregamos las palabras a la Nube y generamos un arreglo con las palbras originales
var_dump($contenido);
foreach($contenido["results"] as $twit){
	//var_dump($twit);
	}
?>
 
