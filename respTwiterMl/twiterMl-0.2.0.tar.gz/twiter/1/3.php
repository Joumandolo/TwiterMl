<?php
#######
## primer experimento con twiter by Jou.
#######

include_once($_SERVER['DOCUMENT_ROOT']."/twiter/twitteroauth2/twitteroauth/twitteroauth.php");

$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);
#$statusMessage = 'test 2 aprendiendo a usar twiter api';
#$tweet->post('statuses/update', array('status' => $statusMessage));

//Buscar twitts}
//$tweet->get('');
//$.getJSON('http://search.twitter.com/search.json?callback=?&'+query
?>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
	<title>TwitSearch</title> 
    
	<style type="text/css"> 
		div#main{
			width: 800px;
			margin: 0 auto;
			background-color:#99CCCC;
			padding:10px;
		}
	</style> 
  
	<script type="text/javascript" src="../jquery/jquery-1.2.6.min.js"></script> 
	<script type="text/javascript" src="../jsOAuth/jsOAuth-1.3.1.min.js"></script> 
    
	<script type="text/javascript"> 
		$(document).ready(function(){
			$('form#search').bind("submit", function(e){
				e.preventDefault();
				$('#content').html('');

				$('#test').html('');

				var palabra = $('input[name="searchTerm"]').val(); //Palabra que se quiere buscar
				var rpp = $('select[name="searchCantidadResultados"] option:selected').val(); //# tweets a mostrar
				var idioma = $('select[name="searchIdioma"] option:selected').val(); //Idioma de la busqueda
				var ubicacion = $('select[name="searchUbicacion"] option:selected').val(); //Ubicacion
	   
				//Calcular las fechas para el query until y since
				if($('select[name="searchFechaHasta"] option:selected').val() > 0){
					var searchFechaHasta = $('select[name="searchFechaHasta"] option:selected').val();
					var fechaHoy = new Date();
					var unDiaMil = 1000*60*60*24;

					var fechaHasta = fechaHoy.getTime() - ((searchFechaHasta - 0) * unDiaMil);
					fechaHasta = new Date(fechaHasta);
					var yyyy = fechaHasta.getFullYear();
					var mm = fechaHasta.getMonth() + 1;
					var dd = fechaHasta.getDate();
					var fechaSince = yyyy+'-'+mm+'-'+dd;
				}else{ var fechaSince = ''; } 

				var query = 'q='+palabra+'&rpp='+rpp+'&lang='+idioma+'&place='+ubicacion+'&since='+fechaSince;
				//var query = 'q='+palabra+'&rpp='+rpp;
				$('#test').append(query);

				$.getJSON('http://search.twitter.com/search.json?callback=?&'+query, function(data){
					$.each(data.results, function(i, item){
						//Contar la cantidad fr RTT de cada Twit
						$.getJSON('http://api.twitter.com/1/statuses/retweets/'+item.id_str+'.json', function(data){
							$.each(data.results, function(i,item){
								var count = count + i + 1;
							
								console.log(item);
								var newDiv = '<p>['+i+']<a href="http://www.twitter.com/'+item.from_user+'">'+item.from_user+'</a> - '+item.text+'<br>[RTT:'+count+']</p>';
								$('#content').append(newDiv);
							});
						});
					});
				});
			})
					        
			function urlencode(str) {
				return escape(str).replace(/\+/g,'%2B').replace(/%20/g, '+').replace(/\*/g, '%2A').replace(/\//g, '%2F').replace(/@/g, '%40');
			}        
		})
	</script> 
</head> 

<body> 
	<div id="main"> 
		<h2>Search Twitter</h2> 
		
		<div> 
			<form id="search" method="post" action="index.html"> 
				Palabra:
				<input type="text" name="searchTerm"/> 
				Ubicacion:
				<select name="searchUbicacion" disabled>
					<option value="">Sin filtro</option> 
					<option value="47a3cf27863714de">Chile</option> 
					<option value="Otro">Otro</option>
				</select>
				Idioma:
				<select name="searchIdioma"> 
					<option value="">Todos</option>
					<option value="es">Español</option>
					<option value="en">Ingles</option>
				</select>
				<br>
				Antiguedad de los twitts:
				<select name="searchFechaHasta"> 
					<option value="0">Ninguna</option>
					<option value="5">5 Dias</option>
					<option value="15">15 Dias</option>
					<option value="30">30 Dias</option>
					<option value="60">2 Meses</option>
					<option value="90">3 Meses</option>
					<option value="180">6 Meses</option>
				</select>
				Cantidad de resultados:		
				<select name="searchCantidadResultados"> 
					<option value="5">5 Twitts</option>
					<option value="10">10 Twitts</option>
					<option value="15">15 Twitts</option>
					<option value="20">20 Twitts</option>
					<option value="40">40 Twitts</option>
					<option value="50">50 Twitts</option>
				</select>

				<input type="submit" name="submit" value="submit" /> 
			</form> 
		</div>

		<div id="content"> </div> 
		<div id="test"> </div> 
	</div> 

<script type="text/javascript"> 
	var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
	document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script> 

<script type="text/javascript"> 
var pageTracker = _gat._getTracker("UA-3230944-1");
//pageTracker._initData();
//pageTracker._trackPageview();
</script> 
 
</body> 
</html> 
