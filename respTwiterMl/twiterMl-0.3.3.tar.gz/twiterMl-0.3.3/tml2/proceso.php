<?php
//sleep(3);
$datos = $_GET["dato1"];
$datos = $datos * 5;
$datos = array("dato2" => $datos);
$datos = json_encode($datos);
header('Content-type: application/json');
echo $datos;
?>

