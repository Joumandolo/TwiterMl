<html lang="en" xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
	<title>TwitML</title> 

   	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script> 

	<script type="text/javascript"> 
		$(document).ready(function(){
			$('form#search').bind("submit", function(e){
				e.preventDefault();
				$('#nube').html('');
				$('#nube2').html('');

				//$.getJSON('buscarEstadisticasJson.php', datosFormJson, function(data){
					//$.each(data, function(i, item){
					//console.log(data);
				//	$('div#nube').append(data.nube);
				//});		
				
				//datos = 0;

				$.ajax({
					url: 'datos.php',
					type:'GET',
					dataType: 'json',
					//data: data,
					async: false,
					success: function(data, textStatus, jqXHR){
						$('div#nube').append(data.dato1);
						datos = data.dato1;
						}
				});
				console.log(datos);

				$.ajax({
					url: 'proceso.php',
					type:'GET',
					dataType: 'json',
					data: {"dato1":datos},
					async: true,
					success: function(data, textStatus, jqXHR){
						$('div#nube2').append(data.dato2);
						}
				});
}); })
	</script> 
</head> 

<body> 
	<div id="main"> 
		<h2>Search Twitter</h2> 
		
		<div> 
			<form id="search" method="post" action="index.html"> 
				Palabra:
				<input type="text" name="searchTerm"/> 
				<input type="submit" name="submit" value="submit" /> 
			</form> 
		</div>

		<div id="nube" style="float:right; position:absolute; top:40px; left:690px; border:3px solid; height:300px; width:300px"> </div> 
		<div id="nube2" style="float:right; position:absolute; top:400px; left:690px; border:3px solid; height:300px; width:300px"> </div> 
	</div> 
</body> 
</html> 
