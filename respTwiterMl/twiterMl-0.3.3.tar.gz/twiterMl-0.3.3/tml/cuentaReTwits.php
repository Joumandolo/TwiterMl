<?php
######## cuentaReTwits.php
### primer experimento con twiter by Jou.
########
#
include_once($_SERVER['DOCUMENT_ROOT']."/twiter/twitteroauth2/twitteroauth/twitteroauth.php");

$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

//Crear objeto que contiene las credenciales de autenticacion
$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Recibir datos por get desde la funcion externa que invoca en formato Json
$query = array(
//	"id" => $_GET["id"],
	"id_str" => $_GET["idstr"]
	);

//Contar Re-Twitts del usando el id del twit solicitado
$respuesta = $tweet->get('statuses/show/'.$query["id_str"]);
$respuesta = json_decode($respuesta,true);
$numeroReTwits = $respuesta["retweet_count"];

$contenido = array("numeroReTwits" => $numeroReTwits);
$contenido = json_encode($contenido);

//volcar el contenido en los heders
header('Content-type: application/json');
echo $contenido;
//$respuesta = json_decode($respuesta,true);
//var_dump($respuesta);
//echo $respuesta["retweet_count"];
//echo $respuesta;
?>

