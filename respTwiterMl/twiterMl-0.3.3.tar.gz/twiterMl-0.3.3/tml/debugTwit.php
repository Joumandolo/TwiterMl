<?php
######## debugTwit.php
## Estes escript forma parte del sistema TwiterML
## 
##
##			By: Jou - joumandolo@gmail.com
########

include_once("../twitteroauth2/twitteroauth/twitteroauth.php");
include("../tagCloud/classes/wordcloud.class.php");

echo '<link rel="stylesheet" href="../tagCloud/css/wordcloud.css" type="text/css">';
 
$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

//Crear objeto que contiene las credenciales de autenticacion
$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Recibir datos por get desde la funcion externa que invoca en formato Json
$query = array(
	"q" => "educacion",
	"until" => "2011-10-3",
	"since_id" => 0,
	"max_id_str" => "100000",
	);

//Buscar twitts
$respuesta = $tweet->get("search.json?", $query);
$contenido = json_decode($respuesta, true);

// Agregamos las palabras a la Nube y generamos un arreglo con las palbras originales
//var_dump($contenido);
//array_pop("results",$contenido);
foreach($contenido as $key => $twit){
	if($key != "results"){
		echo "<br>".$key." -> ".$twit;
	}else echo "<br>".$key." -> ".count($twit);
}

?>
 
