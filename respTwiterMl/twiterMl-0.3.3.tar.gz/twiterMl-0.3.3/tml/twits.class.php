<?php
######## twits.class.php
#
#
#
#
#
########

class twits {
	public $version = '0.1.0';
	public $listaTwits = array();
	public $numeroTwits = 0;
	public $x = 1;

	//Estructura usada para cada twit
	//public $twit = array(
	//	"texto" => null,
	//	"idUsuario" => null
	//);

	/*
	 * PHP 5 Constructor
	 * @parametros $palabras, Array() o String()
	 * @retorno void
	 */
	function __construct(){
		//puede recibir una lista de twits o un solo twit****

		//Si recibe una lista de twits lo asigna el cosntructor
		//if(!$listaTwits){
		//	$this->listaTwits = $listaTwits;
		//}
	}

	/*
	 * Convertir las palabras a un formato estandart
	 * @parametros: string $string
	 * @retorno: $string
	 */
	function limpiaCadenas($string) {
		$string = strtolower($string);
		$string = trim($string);
		$string = strip_tags($string);
		$string = preg_replace('/[^a-z ]/', '', $string);
		return $string;
	}


	/*
	 * Funcion añade un twit nuevo
	 * @parametros $twit proveniente de la consulta a la api
	 * @"retorno void
	 */
	function addTwit($twitAPI){
		//Si recivimos un twit añadimos a la lista
		//$this->numeroTwits++;
		if($twitAPI){
			//$this->numeroTwits = 10;
			$att = array(
				"texto" => $twitAPI["text"],
				"idUsuario" => $twitAPI["from_user_id_str"],
				"nombreUsuario" => $twitAPI["from_user"],
			);
			array_push($this->listaTwits,$att);
			//$this->numeroTwits++;
			//$this->x = 5;
			$this->setX();
		}
	//return $texto;
	}

	function setX(){
		$this->numeroTwits = 9;
	}

	/*
	 * Devuelde el contenido de $listaTwits en formato JSON
	 * @parametros: void
	 * @retorno: $listaTwitsJson
	 */ 
	function twitsJson(){
		return json_encode($this->listaTwits);
	}

	/*
	 * Devuelve una lista con ejemplos de twits para las 5 palabras 
	 * mas pesadas
	 *
	 * @parametrs $palabrasPesadas
	 * @retorno $ejemploTwitsPesados
	 */
	function getTwitsPesados($palabrasPesadas = array()){
		$ejemploTwitsPesados = array();
		$twits = array();

		foreach($palabrasPesadas as $palabra => $contenido){
			$ejemploTwitsPesados[$palabra] = array();
			//$twits = array_slice(shuffle($this->lis taTwits),0,5);
			//$twits = array_slice($this->listaTwits,0,5);
			$twits = $this->listaTwits;

			foreach($twits as $twit){
				if(in_array($palabra, explode(" ",$this->limpiaCadenas($twit["texto"])))){
					array_push($ejemploTwitsPesados[$palabra],$twit["texto"]);
					$ejemploTwitsPesados[$palabra] = array_slice($ejemploTwitsPesados[$palabra],0,5);
				}
			}
		}
		return $ejemploTwitsPesados; 
	}
 
}
