<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>TagCloud Generator:: DMW Technologies Pvt. Ltd.</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Tag Cloud Genrator, DMW Technologies" />
	<meta name="description" content="Tag Cloud Generator" />
	<meta name="author" content="DMW Technologies Pvt. Ltd." />
	<meta name="ROBOTS" content="ALL" />	
	<style type="text/css">
		a:hover { background-color:#EE918E;}
	</style>
</head>
<body>
<div>
<?php
$sampleString="What do you have when a lawyer is buried up to his neck in sand? enough sand.";
$sampleArray=array("Rochak Chauhan,http://www.rochakchauhan.com,4",
				   "DMW Validator,http://www.dmwvalidator.com,6",
				   "PHP Classes,http://www.phpclasses.org,9"
				  );

require_once("TagCloudGenerator.inc.php");
$tagCloudGenerator= new TagCloudGenerator();

//echo $tagCloudGenerator->generateTagCloudFromString("Rochak Chauhan","www.rochakchauhan.com",3);
//echo $tagCloudGenerator->generateTagCloudFromArray($sampleArray);
//echo $tagCloudGenerator->generateTagCloudFromCsv('sample.csv');
//$tagArray=$tagCloudGenerator->generateTagsFromText($sampleString);
echo $tagCloudGenerator->generateTagCloudFromText($sampleString);
?>
</div>
</body>
</html>