<script src="../jsOAuth/jsOAuth-1.3.1.min.js" type="text/javascript"></script>

<script type="text/javascript">

var oauth = OAuth({
	consumerKey: "FrdXQ67TWkCYrre59y2NA",
	consumerSecret: "P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI",
	accessTokenKey: "76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW",
	accessTokenSecret:"TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w"
});

function success(data){
	var timeline = JSON.parse(data.text);
	timeline.forEach(function (element){
		alert(element.text);
	});
}

function failure(data) {
	alert("Throw rotten fruit, something failed");
}

oauth.get("http://api.twitter.com/1/statuses/home_timeline.json", success, failure);

</script>
