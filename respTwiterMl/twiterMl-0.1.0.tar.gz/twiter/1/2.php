<?php

$json = file_get_contents("http://twitter.com/status/user_timeline/marredo.json?count=5", true);//getting the file content
$decode = json_decode($json, true); //getting the file content as array
 
echo "<pre>";
print_r($decode);
echo "</pre>";

?>
