<?php
######## buscarTwitsJsonNube.php
## Estes escript forma parte del sistema TwiterML
## 
## Recibe datos desde TwiterML y procesa una busqueda
## en la Search API de Twiter, con el resultado de los estatuses
## genera varias estadisticas.
##
##			By: Jou - joumandolo@gmail.com
########

include_once($_SERVER['DOCUMENT_ROOT']."/twiter/twitteroauth2/twitteroauth/twitteroauth.php");
include($_SERVER['DOCUMENT_ROOT']."/tagCloud/classes/wordcloud.class.php");

echo '<link rel="stylesheet" href="../../tagCloud/css/wordcloud.css" type="text/css">';
 
$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

//Crear objeto que contiene las credenciales de autenticacion
$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Recibir datos por get desde la funcion externa que invoca en formato Json
$query = array(
	"q" => $_GET["buscaTerm"],
	"rpp" => $_GET["rpp"],
	"lang" => $_GET["buscaIdioma"],
	"place" => $_GET["buscaUbicacion"],
	"since" => $_GET["buscaFechaHasta"],
	"until" => $_GET["buscaFechaDesde"]
	);

//Buscar twitts
$respuesta = $tweet->get("search.json?", $query);
$contenido = json_decode($respuesta, true);

// Creamos una nube de palabras usando el contenido de los estatuses de la consulta
$cloud = new wordCloud();
$cloud->orderBy("size","DESC");
$cloud->setLimit("30");
$cloud->shuffleCloud();

// Recogemos las palabras en un arreglo para ser procesadas para sacar estadisticas
$statPalabras = array();
$statPalabrasLargas = array();
$statListaArticulos = array('el','los','un','unos','la','las','una','unas','al','del');
$statListaPreposiciones = array();

// Agregamos las palabras a la Nube y generamos un arreglo con las palbras originales
foreach($contenido["results"] as $twit){
	// Añadimos todas las palabras
	$statPalabras = array_merge($statPalabras, explode(" ",$twit["text"]));
	}

// Eliminamos palabras de menos de 3 caracteres
foreach($statPalabras as $palabra){
	if(strlen($palabra) > 3){$statPalabrasLargas[] = $palabra;}
	}
		
// Eliminamos los articulos de la lista de palabras largas
$statPalabrasLargas = array_diff($statPalabrasLargas,$statListaArticulos);
//var_dump($statPalabrasLargas);

//agregar palabras a la nube y mostrarla
$cloud->addWords($statPalabrasLargas);
echo $cloud->showCloud();

//calcular algunas estadisticas
$statFuerza = $cloud->wordsArray[$query["q"]]["size"]*100/count($statPalabrasLargas);
echo "Fuerza -> ".round($statFuerza,2)."%";
?>
 
