<?php

include("twits.class.php");
include("estadisticas.class.php");

include_once("../twitteroauth2/twitteroauth/twitteroauth.php");
include_once("../conf/keys.php");

//Crear objeto que contiene las credenciales de autenticacion
$consulta = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Creamos un nuevo objeto twits para recibir las lista por GET
$twits = new twits();
$twits->listaTwits = $_POST["d"]; 

//Creamos el objeto estadisticas y lo llenamos con palabras
$estats = new estadisticas();

foreach($twits->listaTwits as $twit){
	$listaUsuariosId[] = $twit['idUsuario'];
}

$estats->addUsuarios($listaUsuariosId);

foreach($estats->listaPalabras as $key => $palabra){
	$respuesta = $consulta->get("followers/ids.json?", array("screen_name"=>$palabra["palabra"]));
	$contenido = json_decode($respuesta, true);
	$estats->listaPalabras[$key]['peso'] = count($contenido);

	//echo "<br>".$palabra["palabra"]." -> ".$palabra["peso"];
}

var_dump($respuesta);
$listaUsuariosPopulares = $estats->getPalabrasPesadas();
//var_dump($listaUsuariosPopulares);
?>
