<?

		//rescatamos una lista con todos los text de los twits mas el id de usuario que postea
		$statTwits[$statCantidadTwits] = array("text" => $twit["text"], "from_user_id_str" => $twit["from_user_id_str"]);
	
// Consultar a la api por la popularidad de los usuarios que postean
$popularidadUsuarios = array();
foreach($statTwits as $twit){
	$query = array("user_id" => $twit["from_user_id_str"], "stringify_ids" => "true");
	$respuesta = json_decode($tweet->get("followers/ids.json?", $query),true);
	$popularidadUsuarios[$twit["from_user_id_str"]] = count($respuesta);
}
$usuariosPopulares = array_unique($popularidadUsuarios);//array_slice(sort($popularidadUsuarios),0,2);
$statUsuariosPopulares = "<p>Lista de usuarios Populares:";
foreach($usuariosPopulares as $key => $pop){
	$statUsuariosPopulares = $statUsuariosPopulares . "<br>Usuario_id: ".$key." -> ".$pop;
}

	"usuariosPopulares" => $statUsuariosPopulares
);

?>
