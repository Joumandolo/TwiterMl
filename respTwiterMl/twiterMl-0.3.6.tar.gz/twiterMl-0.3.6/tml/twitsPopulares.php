<?php

include("twits.class.php");
include("estadisticas.class.php");

include_once("../twitteroauth2/twitteroauth/twitteroauth.php");
include_once("../conf/keys.php");

//Crear objeto que contiene las credenciales de autenticacion
$consulta = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Creamos un nuevo objeto twits para recibir las lista por GET
$twits = new twits();

//solo rescatamos los twits marcado como populares
foreach($_POST["d"] as $twit){
	if($twit["tipo"] == "popular"){
		$lista[] = $twit;
	}
}
$twits->listaTwits = array_unique($lista);

foreach($twits->listaTwits as $twit){
	$respuesta = $consulta->get("followers/ids.json?", array("screen_name"=>$twit["nombreUsuario"]));
	$contenido = json_decode($respuesta, true);
	echo "<br>* (".count($contenido).")".$twit["nombreUsuario"]."(".$twit["popularidad"].") -> ".$twit["texto"];
}

//$listaUsuariosId = array_unique($listaUsuariosId);
//var_dump($listaUsuariosId);
?>
