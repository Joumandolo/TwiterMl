<?php
$config_keys = array(
	"appId" => '321881001162688',
	"secret" => '88e58c116f570a7264fb13d9a2505a15',
	"fileUpload" => false, // optional
);

?>
