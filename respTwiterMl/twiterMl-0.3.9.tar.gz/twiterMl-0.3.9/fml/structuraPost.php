Array(	
 [data] => Array(
  [0] => Array(
   [id]
   [from] => Array( [name] [id] )
   [to] => Array( [data] => Array( [0] => Array( [name] [category] [id] ) [...] ))
   picture
link
name
description
"properties": [
        {
          "name": "By", 
          "text": "ATAP Asociación de Turismo Aventura de la Patagonia", 
          "href": "http://www.facebook.com/pages/ATAP-Asociaci%C3%B3n-de-Turismo-Aventura-de-la-Patagonia/126036407454070"
        }
      ], 
      "icon": "http://static.ak.fbcdn.net/rsrc.php/v1/yD/r/aS8ecmYRys0.gif", 
      "actions": [
        {
          "name": "Comment", 
          "link": "http://www.facebook.com/40796308305/posts/189551234464719"
        }, 
        {
          "name": "Like", 
          "link": "http://www.facebook.com/40796308305/posts/189551234464719"
        }
      ], 

   [message] 
   OP [message_tags] => Array(
                   [37] => Array(
                      [0] => Array( [id] [name] [offset] [length] )
                      [...]				
                      )
                   )
   [type] => status,link,photo
   [created_time] => 2011-11-28T13:45:10+0000
   [updated_time] => 2011-11-28T13:45:10+0000
   [likes] => Array(
         [data] => Array( [0] => Array( [name] [id] ) [...] )
         [count] => 1
         )
   [comments] => Array(
            [count] => 0
	    )
  )
  [...]
 )
[paging] => Array
        ( [previous] => https://...?method=GET&access_token=&limit=&since=1322487910&__previous=1
          [next] => https://...?method=GET&access_token=&limit=&until=1322482307
        )
)
