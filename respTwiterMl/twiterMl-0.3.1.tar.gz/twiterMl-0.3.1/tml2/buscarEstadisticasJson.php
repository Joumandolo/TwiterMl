<?php
######## buscaStadisticasJson.php
## Estes escript forma parte del sistema TwiterML
## 
## Recibe datos desde TwiterML y procesa una busqueda
## en la Search API de Twiter, con el resultado de los estatuses
## genera varias estadisticas y las devuelve a TwiterML en formato
## JSON
##
##			By: Jou - joumandolo@gmail.com
########

include_once($_SERVER['DOCUMENT_ROOT']."/twiter/twitteroauth2/twitteroauth/twitteroauth.php");
include($_SERVER['DOCUMENT_ROOT']."/tagCloud/classes/wordcloud.class.php");

$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

//Crear objeto que contiene las credenciales de autenticacion
$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);

//Variable obtenidas por GET y configuracion de parametros de busqueda
$q = $_GET["buscaTerm"];
$rpp = 100;
$lang = $_GET["buscaIdioma"];
$place = $_GET["buscaUbicacion"];
$geocode = $_GET["buscaUbicacion"];
$since = $_GET["buscaFechaHasta"];
$until = $_GET["buscaFechaDesde"];
	
//Lista de GEocodes de las regiones de chile RM->13 losRios->14 aricaParin->15 
$geocodeChile = array("-20.217,-70.314,115.93km","-23.644,-70.411,115.93km","-27.367,-70.333,200.31km","-29.908,-71.254,113.65km","-33.063,-71.639,72.24km","-34.167,-70.727,72.22km","-35.427,-71.672,98.16km","-36.773,-73.063,108.62km","-38.740,-72.590,100.68km","-41.472,-72.937,124.36km","-45.570,-72.066,185.84km","-53.163,-70.923,205.01km","-33.438,-70.650,70.02km","-39.808,-73.242,76.59km","-18.479,-70.305,73.29km");

//Definir grupos de geocodes para busquedas de mas de una region
$geocodeZonas = array(
	"chileNorte" => array(1,2),
	//"chileNorte" => array(1,2,3,4,15),
	"chileCentro" => array(13,5,6,7,8),
	"chileSur" => array(9,10,11,12,14),
	"Chile" => array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)
	);

$geocode = $geocodeZonas[$geocode];
$statPalabras = array();

$statCantidadTwits = 0;
foreach($geocode as $region){
	//formamos los query y hacemos las consultas
	$query = array("q" => $q, "rpp" => $rpp, "lang" => $lang, "geocode" =>$geocodeChile[$region]);
	//	"since" => $_GET["buscaFechaHasta"],
	//	"until" => $_GET["buscaFechaDesde"]
	//var_dump($query);

	//Buscar twitts
	$respuesta = $tweet->get("search.json?", $query);
	$contenido = json_decode($respuesta, true);
	//var_dump($contenido);
	foreach($contenido["results"] as $twit){
		// Añadimos todas las palabras
		$statPalabras = array_merge($statPalabras, explode(" ",$twit["text"]));
		//contamos la cantidad de twits que encontramos en la busqueda
		$statCantidadTwits++;
		//rescatamos los primeros 5 twits *** idear un metodo de sacar una muestra equitativa
		if($statCantidadTwits < 6){$statMuestraTwits = $statMuestraTwits ."<br> * ".$twit["text"];}

		//var_dump($contenido);
	}
}
	
// Creamos una nube de palabras usando el contenido de los estatuses de la consulta
$cloud = new wordCloud();
$cloud->orderBy("size","DESC");
$cloud->setLimit("30");
$cloud->shuffleCloud();

// Recogemos las palabras en un arreglo para ser procesadas para sacar estadisticas
$statPalabrasLargas = array();
$statListaArticulos = array('el','los','un','unos','la','las','una','unas','al','del');
$statListaPreposiciones = array('para', 'por', 'segun', 'sin', 'sobre', 'tras');

// Eliminamos palabras de menos de 3 caracteres
foreach($statPalabras as $palabra){
	if(strlen($palabra) > 3){$statPalabrasLargas[] = $palabra;}
	}
		
// Eliminamos los articulos de la lista de palabras largas
$statPalabrasLargas = array_diff($statPalabrasLargas,$statListaArticulos);
$statPalabrasLargas = array_diff($statPalabrasLargas,$statListaPreposiciones);
//var_dump($statPalabrasLargas);

//Crear Nube
$cloud->addWords($statPalabrasLargas);
$statNube = $cloud->showCloud();

//Calcular el total de palabras largas
$totalPalabras = count($statPalabrasLargas);
$statTotalPalabras = "<br>Cantidad de palabras -> ".$totalPalabras;

//Encuentra las 5 palabras mas pesadas
$words = array_slice($cloud->wordsArray,0,5);
//var_dump($words);
foreach($words as $word){
//	var_dump($word);
	$statPalabrasPesadas = $statPalabrasPesadas."<br>".$word["word"]." -> ".$word["size"];
}

//Calcula la fuerza de la palabra mas pesada
$statFuerza = $cloud->wordsArray[$q]["size"]*100/$totalPalabras;
$statFuerza = "<br>Fuerza -> ".round($statFuerza,2)."%";

//Crear JSON con respuesta
$stats = array(
	"nube" => $statNube,
	"cantidadTwits" => "<br>Cantidad de Twits encontrados -> ".$statCantidadTwits,
	"muestraTwits" => $statMuestraTwits,
	"totalPalabras" => $statTotalPalabras,
	"palabrasPesadas" => $statPalabrasPesadas,
	"fuerza" => $statFuerza
);

//volcar contenido JSON
header('Content-type: application/json');
$stats = json_encode($stats);
echo $stats;
?>
 
