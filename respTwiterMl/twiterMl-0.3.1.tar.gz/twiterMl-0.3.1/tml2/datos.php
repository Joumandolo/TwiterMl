<?php
sleep(3);
$datos = array("dato1" => 5);
$datos = json_encode($datos);
header('Content-type: application/json');
echo $datos;
?>
