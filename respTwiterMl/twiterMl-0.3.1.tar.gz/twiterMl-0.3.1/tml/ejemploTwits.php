<?php

include("twits.class.php");
include("estadisticas.class.php");

//Creamos un nuevo objeto twits para recibir las lista por GET
$twits = new twits();
$twits->listaTwits = $_POST["d"]; 

//$aleatorio = shuffle($twits->listaTwits);
$aleatorio = $twits->listaTwits;
$muestra = array_slice($aleatorio,0,5);

foreach($muestra as $twit){
	echo "<br>* ".$twit["texto"];
}
//echo count($aleatorio);
//echo "hola";
?>
