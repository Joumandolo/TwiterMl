<?php
//sleep(3);
include("../tagCloud/classes/wordcloud.class.php");
include("twits.class.php");
include("estadisticas.class.php");

echo '<link rel="stylesheet" href="../tagCloud/css/wordcloud.css" type="text/css">';

//Creamos un nuevo objeto twits para recibir las lista por GET
$twits = new twits();
$twits->listaTwits = $_POST["d"]; 

//Creamos el objeto estadisticas y lo llenamos con palabras
$estats = new estadisticas();
foreach($twits->listaTwits as $twit){
        $estats->addFrase($twit["texto"]);
}

//creamos un nuevo objeto Nube
$nube = new wordCloud();
$nube->orderBy("size","DESC");
$nube->setLimit("20");
$nube->shuffleCloud();
$nube->addWords($estats->getPalabrasLargas());

//header('Content-type: application/json');
//echo json_encode(array("nube"=>$nube->showCloud()));
//echo json_encode(array("nube"=>$estats->getPalabrasLargas()));
echo $nube->showCloud();
?>
