<?php

include("twits.class.php");
include("estadisticas.class.php");

//Creamos un nuevo objeto twits para recibir las lista por GET
$twits = new twits();
$twits->listaTwits = $_POST["d"]; 

//Creamos el objeto estadisticas y lo llenamos con palabras
$estats = new estadisticas();
foreach($twits->listaTwits as $twit){
        $estats->addFrase($twit["texto"]);
}

//$twits->setX();
//$twits->numeroTwits = 20;
//mostramos el total de twits encontrados
//echo "<br>Cantidad de Twits procesados: ".$twits->x;
echo "<br>Cantidad de Twits procesados: ".$twits->numeroTwits;
echo "<br>Cantidad de palabras procesadas: ".$estats->numeroPalabras;
echo "<br>Fuerza de la palabra buscada: ".$estats->getFuerza()."%";
?>
