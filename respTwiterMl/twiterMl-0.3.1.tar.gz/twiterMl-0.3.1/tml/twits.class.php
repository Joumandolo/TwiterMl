<?php
######## twits.class.php
#
#
#
#
#
########

class twits {
	public $version = '0.1.0';
	public $listaTwits = array();
	public $numeroTwits = 0;
	public $x = 1;

	//Estructura usada para cada twit
	//public $twit = array(
	//	"texto" => null,
	//	"idUsuario" => null
	//);

	/*
	 * PHP 5 Constructor
	 * @parametros $palabras, Array() o String()
	 * @retorno void
	 */
	function __construct(){
		//puede recibir una lista de twits o un solo twit****

		//Si recibe una lista de twits lo asigna el cosntructor
		//if(!$listaTwits){
		//	$this->listaTwits = $listaTwits;
		//}
	}

	/*
	 * Funcion añade un twit nuevo
	 * @parametros $twit proveniente de la consulta a la api
	 * @"retorno void
	 */
	function addTwit($twitAPI){
		//Si recivimos un twit añadimos a la lista
		//$this->numeroTwits++;
		if($twitAPI){
			//$this->numeroTwits = 10;
			$texto = $twitAPI["text"];
			$idUsuario = $twitAPI["from_user_id_str"];
			array_push($this->listaTwits,array("texto"=>$texto,"idUsuario"=>$idUsuario));
			//$this->numeroTwits++;
			//$this->x = 5;
			$this->setX();
		}
	//return $texto;
	}

	function setX(){
		$this->numeroTwits = 9;
	}

	/*
	 * Devuelde el contenido de $listaTwits en formato JSON
	 * @parametros: void
	 * @retorno: $listaTwitsJson
	 */ 
	function twitsJson(){
		return json_encode($this->listaTwits);
	}

	/*
	 * Devuelve una lista con ejemplos de twits para las 5 palabras 
	 * mas pesadas
	 *
	 * @parametrs $palabrasPesadas
	 * @retorno $ejemploTwitsPesados
	 */
	function getTwitsPesados($palabrasPesadas = array()){
		$ejemploTwitsPesados = array();
		$twits = array();

		foreach($palabrasPesadas as $palabra){
			$palabra = $palabra["palabra"];
			$ejemploTwitsPesados = array_push($palabra);
			//$limit = 0;
			//$twits = array_slice(shuffle($this->listaTwits),0,5);
			$twits = array_slice($this->listaTwits,0,5);

			foreach($twits as $twit){
				//buscamos la palabra pesada en los twits y nos quedamos con el indice
				if(in_array($palabra, explode(" ",$twit["texto"]))){
					//$limite++;
					$ejemploTwitsPesados[$palabra] = array_push($twit["texto"]);
					//if($limite > 5){$limite = 0; break;}
				}
			}
		}
		return $ejemploTwitsPesados; 
	}
 
}
