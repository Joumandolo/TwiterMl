<?php
	include($_SERVER['DOCUMENT_ROOT']."/tagCloud/classes/wordcloud.class.php");
?>

<link rel="stylesheet" href="./css/wordcloud.css" type="text/css">

<?php
$cloud = new wordCloud();
$cloud->addWord('php'); // Basic Method of Adding Keyword
$cloud->addWord(array('word' => 'google', 'size' => 2, 'url' => 'http://www.google.com')); // Advanced user method
$cloud->addWord(array('word' => 'digg', 'url' => 'http://digg.com'));
$cloud->addWord(array('word' => 'lotsofcode', 'size' => 4, 'url' => 'http://www.lotsofcode.com'));
echo $cloud->showCloud();
?>
