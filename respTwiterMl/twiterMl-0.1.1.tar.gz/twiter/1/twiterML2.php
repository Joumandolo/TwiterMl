<?php
####### twiterML2.php
## Avanzando hacia Twiter Machine Learnig.
##
## Tomamos datos de un formulario de busqueda avanzada
## consultamos a Twiter con la Search API luego usamos el "text"
## o los statuses y los procesamos con varios filtros
##
##
##			By: Jou - joumandolo@gmail.com
#######
?>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
	<title>TwitML</title> 

	<link rel="stylesheet" href="../../tagCloud/css/wordcloud.css" type="text/css">
<!--
	<style type="text/css"> 
		div#main{
			width: 800px;
			margin: 0 auto;
			background-color:#99CCCC;
			padding:10px;
		}
	</style> 
  -->
	<!-- >script type="text/javascript" src="../jquery/jquery-1.2.6.min.js"></script> -->
   	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script> 

	<script type="text/javascript"> 
		$(document).ready(function(){
			$('form#search').bind("submit", function(e){
				e.preventDefault();
				$('#nube').html('');
				$('#estadisticas').html('');
				$('#muestras').html('');

				//Recogemos los datos del formulario y creamos una estructura json
				var datosFormJson = {};
                                datosFormJson.buscaTerm = $('input[name="searchTerm"]').val();
				datosFormJson.rpp = $('select[name="searchCantidadResultados"] option:selected').val();
				datosFormJson.buscaIdioma = $('select[name="searchIdioma"] option:selected').val();
				datosFormJson.buscaUbicacion = $('select[name="searchUbicacion"] option:selected').val();
/*
				//Calcular las fechas para el query until y since
				if($('select[name="searchFechaHasta"] option:selected').val() > 0){
					var buscaFechaHasta = $('select[name="searchFechaHasta"] option:selected').val();
					var fechaHoy = new Date();
					var unDiaMil = 1000*60*60*24;
					var fechaHasta = Date(fechaHoy.getTime() - ((buscaFechaHasta - 0) * unDiaMil));
					
					var yyyy = fechaHasta.getFullYear();
					var mm = fechaHasta.getMonth() + 1;
					var dd = fechaHasta.getDate();
					fechaHasta = yyyy+'-'+mm+'-'+dd;
				}else{ var fechaHasta = ''; }
 */	
				//datosFormJson.searchFechaHasta = fechaHasta;
				datosFormJson.buscaFechaDesde = $('select[name="searchFechaDesde"] option:selected').val();
				datosFormJson.buscaFechaHasta = $('select[name="searchFechaHasta"] option:selected').val();

				$.getJSON('buscarEstadisticasJson.php', datosFormJson, function(data){
					//$.each(data, function(i, item){
					//console.log(data);
					$('div#nube').append(data.nube);
					$('div#estadisticas').append(data.totalPalabras+"<br>");
					$('div#estadisticas').append(data.cantidadTwits+"<br>");
					$('div#estadisticas').append(data.palabrasPesadas+"<br>");
					$('div#estadisticas').append(data.fuerza);
					$('div#muestras').append(data.muestraTwits);
				});						

/*
				var bodyContent = $.ajax({
					url: "buscaEstadisticasJson.php",
					global: false,
					type: "GET",
					data: datosFormJson,
					dataType: "html",
					//async:false,
					success: function(msg){
						$('div#nube').append(msg);
						},
					error: function(msg){
						$('div#nube').append(msg);
						}
					}).responseText;
 */
				});
			})		        
	</script> 
</head> 

<body> 
	<div id="main"> 
		<h2>Search Twitter</h2> 
		
		<div> 
			<form id="search" method="post" action="index.html"> 
				Palabra:
				<input type="text" name="searchTerm"/> 
				Ubicacion:
				<select name="searchUbicacion">
					<option value="">Sin filtro</option> 
					<option value="chileNorte">Norte de Chile</option> 
					<option value="chileCentro">Centro de Chile</option>
					<option value="chileSur">Sur de Chile</option>
					<option value="Chile">Chile Continetal</option>
				</select>
				Idioma:
				<select name="searchIdioma"> 
					<option value="">Todos</option>
					<option value="es">Español</option>
					<option value="en">Ingles</option>
				</select>
				<br>
				Twitts desde:
				<select name="searchFechaDesde"> 
					<option value="2011-08-30">5 Dias</option>
					<option value="2011-08-25">15 Dias</option>
					<option value="2011-08-15">30 Dias</option>
					<option value="2011-07-30">2 Meses</option>
					<option value="2011-06-30">3 Meses</option>
					<option value="2011-05-30">6 Meses</option>
				</select>
				Twitts hasta:
				<select name="searchFechaHasta"> 
					<option value="2011-08-29">5 Dias</option>
					<option value="2011-08-24">15 Dias</option>
					<option value="2011-08-14">30 Dias</option>
					<option value="2011-07-29">2 Meses</option>
					<option value="2011-06-29">3 Meses</option>
					<option value="2011-05-29">6 Meses</option>
				</select>
				Cantidad de resultados:		
				<select name="searchCantidadResultados" disabled> 
					<option value="5">5 Twitts</option>
					<option value="25">10 Twitts</option>
					<option value="125">15 Twitts</option>
					<option value="625">20 Twitts</option>
					<option value="3125">40 Twitts</option>
					<option value="15625">50 Twitts</option>
				</select>

				<input type="submit" name="submit" value="submit" /> 
			</form> 
		</div>

		<div id="estadisticas"> </div> 
		<div id="nube" style="float:right; position:absolute; top:40px; left:690px; border:3px solid; height:300px; width:300px"> </div> 
		<div id="muestras"> </div> 
		<div id="test"> </div> 
	</div> 
</body> 
</html> 
