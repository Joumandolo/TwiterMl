<?php
#######
# primer experimento con twiter by Jou.
######

include_once($_SERVER['DOCUMENT_ROOT']."/twiter/twitteroauth2/twitteroauth/twitteroauth.php");

$consumerKey    = 'FrdXQ67TWkCYrre59y2NA';
$consumerSecret = 'P5rLruQhM96ZgSgAa3WZBahfilFEDYhgXDuhlUcR2lI';
$oAuthToken     = '76760096-zCQXaqkK1RFQibNaimCNRqGa8RcJUcOpctWfOeLW0';
$oAuthSecret    = 'TFgsHSYwfpFVCWrrVq8fQbLiSumu0rie4GT9xTU97w';

$tweet = new TwitterOAuth($consumerKey, $consumerSecret, $oAuthToken, $oAuthSecret);
$statusMessage = 'test 2 aprendiendo a usar twiter api';
$tweet->post('statuses/update', array('status' => $statusMessage));

/*
function updateTwitter($status){
	// datos de login de twiter 
	$username = "marredo"; 
	$password = ".45484548";
 
	// The url of the update function 
	$url = 'http://twitter.com/statuses/update.xml'; 

	// Arguments we are posting to Twitter 
	$postargs = 'status='.urlencode($status); 

	// Will store the response we get from Twitter 
	$responseInfo=array(); 

	// Initialize CURL 
	$ch = curl_init($url); 

	// Tell CURL we are doing a POST 
	curl_setopt ($ch, CURLOPT_POST, true); 

	// Give CURL the arguments in the POST 
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $postargs);

	// Set the username and password in the CURL call 
	curl_setopt($ch, CURLOPT_USERPWD, $username.':'.$password); 

	// Set some cur flags (not too important) 
	curl_setopt($ch, CURLOPT_VERBOSE, 1); 
	curl_setopt($ch, CURLOPT_NOBODY, 0); 
	curl_setopt($ch, CURLOPT_HEADER, 0); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION,1); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 

	// execute the CURL call 
	$response = curl_exec($ch); 

	// Get information about the response 
	$responseInfo=curl_getinfo($ch); 

	// Close the CURL connection
	#$curl_close($ch); 

	// Make sure we received a response from Twitter 
	if(intval($responseInfo['http_code'])==200){ 
		// Display the response from Twitter 
		echo $responseInfo;
		echo $response."aaaa"; 
	}else{ 
		// Something went wrong 
		echo "Error: " . $responseInfo['http_code']; 
	} 
} */

?> 
