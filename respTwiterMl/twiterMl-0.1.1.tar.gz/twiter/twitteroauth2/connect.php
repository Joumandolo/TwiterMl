<?php

/**
 * @file
 * Get a request token from twitter and present authorization URL to user
 */

$content = '<a href="./redirect.php"><img src="./images/lighter.png" alt="Sign in with Twitter"/></a>';
 
/* Include HTML to display on the page */
include('html.inc');
